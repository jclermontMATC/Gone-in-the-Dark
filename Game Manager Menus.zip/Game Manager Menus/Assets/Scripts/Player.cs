﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour{
    public int hp;
    public int stam;
    public int oil;
    Vector3 position;
}
